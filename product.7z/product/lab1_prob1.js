var employee=[];
employee.push('Anjula','John','Peter','Karthik','Senthil','Arohi');
for(var key in employee){
    console.log(employee[key]);
}