var express = require('express');
var http = require('http');
var cors = require('cors');
var parser=require('body-parser');
var fs=require('fs');
var MongoClient = require('mongodb').MongoClient
var url = "mongodb://localhost:27017/";
var exp = express()

exp.get("/rest/api/load",cors(),(req,res)=>{
    console.log('Load Invoked');
    res.send({msg:'Give Some rest to the world'});
    
});


exp.route('/rest/api/get',cors()).get((req,res)=>{
    console.log("Get Invoked");
    res.send({msg:'Hello World'});
    MongoClient.connect(url, function(err, db) {
  if (err) throw err;
  var dbo = db.db("mydb");
  //var query={age:"34785",name:"zlkxhf"};
  dbo.collection("customers").find({}).toArray(function(err, result) {
    if (err) throw err;
    console.log(result);
      
    db.close();
  });

});
    
});

exp.use(parser.json());

exp.route('/rest/api/post',cors()).post((req,res)=>{
    console.log(req.body);
    fs.writeFile('demo.json',JSON.stringify(req.body));
    res.status(201).send(req.body);
    /*----Creating database ----*/
MongoClient.connect(url, {useNewUrlParser:true},function(err, db) {
  if (err) throw err;
console.log("Database Created");
  var coll = db.db("mydb");
  /*Create a collection name "customers":
  coll.createCollection("customers", function(err, res) {
    if (err) throw err;
    console.log("Collection created!");
    db.close();
  });*/
var mydata={"firstname":"Haritha","lastname":"Hari"};
coll.collection("customers").insert(req.body,function(err,res){
    if(err) throw err;
    console.log("1 document is inserted");
    db.close();
});
});

})

exp.route('/rest/api/get/:name').get((req,res)=>{
    res.send("Hello World"+req.params['name']);
})
exp.route('/rest/api/put',cors()).post((req,res)=>{
    console.log("Put Invoked");
     console.log(req.body);
    fs.writeFileSync('demo.json',JSON.stringify(req.body));
    res.status(201).send(req.body);
    MongoClient.connect(url, function(err, db) {
  if (err) throw err;
  var dbo = db.db("mydb");
  var myquery = { name:"charan"};
  var newvalues = { $set: {address: "Bangalore" } };
  dbo.collection("customers").updateOne(myquery, newvalues, function(err, res) {
    if (err) throw err;
    console.log("1 document updated");
    db.close();
  });
});
})
exp.route('/rest/api/delete').post((req,res)=>{
    console.log("Delete invoked");
    MongoClient.connect(url, function(err, db) {
  if (err) throw err;
  var dbo = db.db("mydb");
  console.log(req.body);
  //var myquery = { name:"nolj" };
  //var id=req.body._id;
  dbo.collection("customers").deleteOne(req.body, function(err, obj) {
    if (err) throw err;
    if(obj.result.n==0)
    console.log("Data not found");
    else
    console.log(obj.result.n +" document deleted");
    db.close();
  });
});

})

exp.listen(3000);
