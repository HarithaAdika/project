var express = require('express');
var http = require('http');
var cors = require('cors');
var parser=require('body-parser');
var fs=require('fs');
var exp = express()
var prodData = fs.readFileSync('./products.json')
prodData = JSON.parse(prodData);

exp.route('/products/get',cors()).get((req,res)=>{
    

    console.log(prodData);
    res.send(prodData);
});
exp.route('/products/add',cors()).post((req,res)=>{


})







exp.listen(3200,()=>{
    console.log("Listening...............");
});