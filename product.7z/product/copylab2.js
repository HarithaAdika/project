var express = require('express');
var http = require('http');
var cors = require('cors');

var fs=require('fs');
var MongoClient = require('mongodb').MongoClient
var url = "mongodb://localhost:27017/";
var exp = express()
var parser = require('body-parser');
var jsondata = fs.readFileSync('./employee.json')

jsondata = JSON.parse(jsondata);

exp.get("/rest/api/load",cors(),(req,res)=>{
    console.log('Load Invoked');
    res.send({msg:'Give Some rest to the world'});
    dbo.collection("productColl").find({}).toArray(function(err, result) {
    if (err) throw err;  
    console.log("-----Get All Data---------");  
    console.log(result);
        });
});

var dbo;
 MongoClient.connect(url, function(err, db) {
  if (err) throw err;
    dbo = db.db("mydb");
});

/*--------------INserting the employee data into database------------------*/

exp.route('/rest/api/get',cors()).get((req,res)=>{
    console.log("Get Invoked");
    res.send({msg:'Hello World'});
   let data = fs.readFileSync('employee.json');
    let employee = JSON.parse(data);
  dbo.collection("productColl").insertMany(employee, function(err, res) {
    if (err) throw err;
    console.log("Number of products inserted: " + res.insertedCount);
      
    
  });

    
});

exp.use(parser.json());
/*------------Displaying Data baesd on state-----------------------*/

exp.route('/rest/api/get/:state').get((req,res)=>{
    res.send("Employees from state"+req.params['state']);
    
    
           dbo.collection("productColl").find({'empAddress.state':req.params['state']}).toArray(function(err,res){
               if(err) throw err;
                console.log(res);
           });
           
     });
/*------------Updating the city-----------------------*/
exp.route('/rest/api/update/:id/:city').get((req,res)=>{
     res.send("Employees from id"+req.params['id']+""+req.params['city']);
     dbo.collection("productColl").updateOne({'empId':eval(req.params['id'])},{$set:{'empAddress.city':req.params['city']}},function(err,res){
               if(err) throw err;
            console.log('1 document updated');
           });     
         
})
/*-----------Adding the new employee-----------------------*/
exp.use(parser.json());
exp.route('/rest/api/post').post((req,res)=>{
    console.log("Post Invoked");
    
    console.log(req.body);
    dbo.collection('productColl').insertOne(req.body,function(err,res){
        if(err) throw err;
        console.log('1 document inserted');
    })
});
/*
exp.route('/rest/api/post',cors()).post((req,res)=>{
    console.log("Post Invoked");
    let data={
        "empId":1101,
        "empName":'Charan',
        "empSalary":500000,
        "empAddress":{"city":'Bangalore',"state":'Karnataka'}

    }
    
    dbo.collection('productColl').insert(data,function(err,res){
        if(err) throw err;
        console.log('1 document inserted');
    })
    
   

});*/


/*------------Updating the city-----------------------*/
exp.route('/rest/api/update/:id/:city').put((req,res)=>{
     res.send("Employees from id"+req.params['id']+""+req.params['city']);
     dbo.collection("productColl").updateOne({'empId':eval(req.params['id'])},{$set:{'empAddress.city':req.params['city']}},function(err,res){
               if(err) throw err;
            console.log('1 document updated');
           });     
                  
});
/*
exp.route('/rest/api/update/:id/:city').post((req,res)=>{
     res.send("Employees from id"+req.params['id']+""+req.params['city']);
     dbo.collection("productColl").updateOne({'empId':eval(req.params['id'])},{$set:{'empAddress.city':req.params['city']}},function(err,res){
               if(err) throw err;
            console.log('1 document updated');
           });     
         
})*/
exp.get('/userform.html', function (req, res) {  
   res.sendFile( __dirname + "/" + "userform.html" );  
}) 
  exp.post('/rest/api/form',function (req, res) {
    console.log("Post Invoked");
   let data = {
        "empId": req.body.id,
        "empName": req.query['name'],
        "empSalary": req.query.salary,
        "empAddress": {
            "city": req.query.city,
            "state": req.query.state,
        }
    }
    console.log(data);
    dbo.collection('productColl').insert(data,function(err,res){
        if(err) throw err;
        console.log('1 document inserted');
    });
    
   

});


exp.listen(3000);
