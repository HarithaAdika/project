import { Injectable } from '@angular/core';

import {HttpClient} from '@angular/common/http';
import {Observable,of} from 'rxjs'
@Injectable({
  providedIn: 'root'
})
export class CallerService {

  constructor(private http:HttpClient)   { }
 
getUrl='http://localhost:3000/rest/api/get';
  getData() {
    return this.http.get(this.getUrl);
  }
 postData(ename:string,eage:number):Observable<any>{
   console.log("ENAME:"+ename);
   console.log("EAGE:"+eage);
   return this.http.post('http://localhost:3000/rest/api/post',{
     name:ename,
     age:eage
   })
 }
 deleteData(d:any){
   return this.http.post('http://localhost:3000/rest/api/delete',{
name:d
     
   });

 }
 updateData(){
   return this.http.post('http://localhost:3000/rest/api/put',{
     
   })
 }

}
