import { TestBed, inject } from '@angular/core/testing';

import { ServicecallService } from './servicecall.service';

describe('ServicecallService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ServicecallService]
    });
  });

  it('should be created', inject([ServicecallService], (service: ServicecallService) => {
    expect(service).toBeTruthy();
  }));
});
