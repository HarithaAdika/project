import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-node-example',
  templateUrl: './node-example.component.html',
  styleUrls: ['./node-example.component.css']
})
export class NodeExampleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
