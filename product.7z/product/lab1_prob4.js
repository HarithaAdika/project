var express = require('express');  
var app=express(); 
app.get('/userlogin.html', function (req, res) {  
   res.sendFile( __dirname + "/" + "userlogin.html" );  
})   
app.get('/lab1_prob4', function (req, res) {  
res.send('<h3>The user logged in with </h3>'+'<p>Username: ' + req.query['uname']+'</p><p>Password: '+req.query['pswd']+'</p>');  
})  
var server = app.listen(8000, function () {  
  var host = server.address().address  
  var port = server.address().port  
  console.log("Login application listening at http://%s:%s", host, port)  
}) 